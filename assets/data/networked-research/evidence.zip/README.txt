EigenEngine reading guide

Open index.html to read the guide offline. Its evidence links open files in this archive. Interactive exhibits link to the public website.
index.json contains the public guide's machine-readable manifest. Use each file's archive_path when present, its relative URL otherwise, or the site-relative path for an absolute URL.
SHA256SUMS.txt lists the checksums of the archive members. The manuscript excerpts preserve the recorded UTF-8 bytes including whitespace.
ask-your-agent.txt contains the exact text of the public explanation prompt.
