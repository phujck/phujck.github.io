Networked Research source records

Open index.html for the reading guide or index.json for the machine-readable manifest.
Raw source excerpts preserve the recorded UTF-8 bytes, including whitespace.
Relative file URLs in the manifest resolve beside index.json. For an absolute URL
on gmccaul.co.uk, use the corresponding assets/ path in this archive.
SHA256SUMS.txt lists the checksums of the archive members.
ask-your-agent.txt contains the public investigation prompt.
