The Cost of Complexity: A Physical Theory of Representation

1. In a fresh conversation, send first-message.txt by itself and keep the reply.
2. Then send second-message.txt in the same conversation. You can attach paper.zip
   with that second message. The reading page also offers the original PDF, a
   browser transcript and the follow-up with the complete paper as plain text.

The PDF preserves the original typesetting for reading or printing. The UTF-8
transcript includes the equations, captions, references and end matter. The
caption of each figure gives its image path and published page.

Reading page: https://gmccaul.co.uk/eigenengine/cost-of-complexity/reading/
SHA256SUMS.txt lists the digest of every other file in this archive.
