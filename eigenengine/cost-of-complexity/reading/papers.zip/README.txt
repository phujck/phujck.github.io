Paired reading of The Cost of Complexity and Physical origins of the Kalmár constant

1. Send the abstract-only opening from the reading page in a fresh conversation.
   Keep the agent’s first reply.
2. After that reply, send follow-up.txt in the same conversation. Attach papers.zip
   if your agent needs an attachment. The reading page also offers the manuscripts
   directly, so the exercise can be completed in a browser.

Each paper appears as an original, printable PDF and a complete UTF-8 text file.
The text files include the equations, captions, references and end matter. Figure
captions name the corresponding image under cost/ or kalmar/. The Cost figures
are 1–6 and the Kalmár figures are 1–3. Use the PDFs for the original typesetting.

Reading page: https://gmccaul.co.uk/eigenengine/cost-of-complexity/reading/
SHA256SUMS.txt lists the SHA-256 digest of each other file in this archive.
